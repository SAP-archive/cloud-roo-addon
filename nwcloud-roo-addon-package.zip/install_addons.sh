#!/bin/bash

#
# Copyright 2012 SAP AG
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

echo Installing artifacts to local Maven repository.
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo  - Artifact directory = $DIR

MVN_PLUGIN=nwcloud-maven-plugin-1.0.0.RELEASE
ROO_ADDON_1=com.sap.research.roo.addon.nwcloud-1.0.0.RELEASE

mvn install:install-file -Dfile="$DIR/$MVN_PLUGIN.jar" -DpomFile="$DIR/$MVN_PLUGIN.pom"
mvn install:install-file -Dfile="$DIR/$ROO_ADDON_1.jar" -DpomFile="$DIR/$ROO_ADDON_1.pom"

echo Creating Roo script "install.roo" for installing Roo addon.
ROO_ADDON_1=$DIR/$ROO_ADDON_1.jar
echo "osgi start --url file:///${ROO_ADDON_1// /%20}" > install.roo
echo  - Done

echo Execute generated "install.roo" script using Roo.
roo.sh script --file install.roo
echo  - Done