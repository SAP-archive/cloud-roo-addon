====================
= Download Package =
====================

This download package provides you with:
 - SAP NetWeaver Cloud Addon for Spring Roo
 - SAP NetWeaver Cloud Deployment Plugin for Maven
 - Installer script
 - Installation instructions (this file)

All contents copyrighted by SAP AG and made available under the Apache License 2.0 (see file "LICENSE").


Installing the prerequisites - Roo and Maven
============================================

A basic requirement to get started with our addon and plugin, is a working installation of Roo and Maven.

The easiest way to get both, is to download the "SpringSource Tool Suite" (STS) from SpringSource. STS is an Eclipse-based IDE bundled with Spring technology like Roo.

STS can be downloaded here:

	http://www.springsource.org/sts

After installing STS in a directory of your choice, you will find certain subdirectories there, e.g.

	spring-roo-1.2.1.RELEASE
	apache-maven-3.0.3

Please make sure, that the "bin" directories of these folders are on the path, so that you are able to call the commands "roo" and "mvn" in whichever directory you are on the commandline. (Note: If you are using Linux or Mac OS then the command to start the Roo Shell is "roo.sh".)

If you are behind a proxy, then please start Roo and issue the command "proxy configuration" on the Roo Shell in order to check if the right HTTP proxy is used by Roo. Information on how to set a proxy in Maven will be given later in this document.

If you have trouble installing STS, Roo, or Maven we would like to refer you to the official websites, where you will find more detailed instructions and a community forum to ask questions.

Websites:
 - STS: http://www.springsource.org/sts
 - Roo: http://www.springsource.org/spring-roo
 - Maven: http://maven.apache.org/


Installing the Roo addon and Maven plugin
=========================================

Extract contents of ZIP
-----------------------

Extract all the contents of the ZIP file containing this "readme.txt" you are currently reading to a folder of your choice. In the following this folder will be called "ROO_ADDONS".

Whenever in the following commands or instructions the term "ROO_ADDONS" is used, please replace the term by the fully qualified path to the directory, where you extracted the contents of the ZIP file.


Installing to local Maven repository and Roo
--------------------------------------------

Open a commandline and change to the directory "ROO_ADDONS". There execute the following command to install required artifacts to the local Maven repository and Roo:

If you are using Windows:

	install_addons.bat

If you are using Linux or Mac:

	chmod +x ./install_addons.sh
	./install_addons.sh


Checking installation in Roo
----------------------------

Start the Roo Shell and issue the following command to get the list of loaded OSGi bundles in Roo:

	osgi ps

You should see the installed addon at the end of the appearing list, similar to this:

	...
	[  74] [Active     ] [    1] nwcloud-roo-addon (1.0.0.RELEASE)
	...

If you see a line like this, then the addon has successfully been installed to Roo.

If such a line does not show up in the list, then try to manually install the addon using the following command:

	osgi start --url file:///ROO_ADDONS/com.sap.research.roo.addon.nwcloud-1.0.0.RELEASE.jar

Hint: If there are any spaces in the path "ROO_ADDONS" please replace each of them with "%20" in the command.

If you ever need to uninstall the addon, then this can be done by the following command on the Roo shell:

	osgi uninstall --bundleSymbolicName com.sap.research.roo.addon.nwcloud


Maven: Enable group "com.sap.research" and configure proxy
----------------------------------------------------------

Figure out where your currently used Maven configuration file "settings.xml" is located. Usually this is in the "conf" directory of your local Maven installation or in the "~/.m2" directory of your user (using Windows this would be something like "c:\Users\YourUser\.m2").

In "settings.xml" search for the "pluginGroups" tag and insert "com.sap.research" as an artifact group that contains plugins, like this:

	<pluginGroups>
		<!--pluginGroup
		| Specifies a further group identifier to use for plugin lookup.
		-->
		<pluginGroup>com.sap.research</pluginGroup>
	</pluginGroups>

If you are behind a proxy, then also search for the "proxies" tag and insert a "proxy" tag defining your proxy settings, like this:

	<proxies>
		<!-- proxy
		| Specification for one proxy, to be used in connecting to the network.
		-->
		<proxy>
			<id>MyProxy</id>
			<active>true</active>
			<protocol>http</protocol>
			<host>proxy</host>
			<port>8080</port>
			<nonProxyHosts>localhost</nonProxyHosts>
		</proxy>
	</proxies>


SAP NetWeaver Cloud SDK
-----------------------

When you actually use the Roo addons later on, and want to deploy a created application to SAP NetWeaver Cloud, the SAP NetWeaver Cloud SDK (Neo SDK) will be needed by a Maven plugin to actually do the deployment in an automated way for you. As a preparational step, you could download the SDK now and extract it to a directory of your choice. A current version of the SDK can always be downloaded here:

	https://tools.netweaver.ondemand.com/

In whichever directory you extract the SDK to, please remember that this directory exists and where it is. You will need to define this directory in a settings file later on, before you are actually able to deploy web applications to the SAP NetWeaver Cloud platform. Please follow the tutorial we have prepared to learn on how and where to set this setting.


And now?
--------

Everything should be set up now.

You could now start the tutorial for Roo on SAP NetWeaver Cloud which is available here:

	http://mispdev.github.com/nwcloud-roo-addon/tutorial.html


Additional information
----------------------

License

This project is copyrighted by SAP AG (http://www.sap.com/) and made available under the Apache License 2.0 (http://www.apache.org/licenses/LICENSE-2.0.html). Please also confer to the text files "LICENSE" and "NOTICE" included with this project.

Contributions

Contributions to this project are very welcome, but can only be accepted if the contributions themselves are given to the project under the Apache License 2.0 (http://www.apache.org/licenses/LICENSE-2.0.html). Contributions other than those given under Apache License 2.0 will be rejected.